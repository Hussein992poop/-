import React, { useState, useEffect } from 'react';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  serverTimestamp,
  getDoc,
  doc,
  setDoc
} from 'firebase/firestore';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged, 
  signOut,
  User
} from 'firebase/auth';
import { db, auth } from './firebase';
import { Doctor, Booking, UserProfile } from './types';
import { DoctorCard } from './components/DoctorCard';
import { 
  Search, 
  User as UserIcon, 
  LogOut, 
  Calendar, 
  Plus, 
  X,
  ClipboardList,
  CheckCircle2,
  Clock as ClockIcon,
  Stethoscope
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format } from 'date-fns';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('الكل');
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [bookingDate, setBookingDate] = useState('');
  const [bookingTime, setBookingTime] = useState('');
  const [patientPhone, setPatientPhone] = useState('');
  const [isAuthReady, setIsAuthReady] = useState(false);

  const specialties = ['الكل', 'قلبية', 'نسائية', 'أطفال', 'باطنية', 'جراحة', 'جلدية', 'أسنان', 'عيون'];

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        const profileDoc = await getDoc(doc(db, 'users', currentUser.uid));
        if (profileDoc.exists()) {
          setProfile({ id: currentUser.uid, ...profileDoc.data() } as UserProfile);
        } else {
          // Create default patient profile
          const newProfile: Omit<UserProfile, 'id'> = {
            name: currentUser.displayName || 'مريض',
            email: currentUser.email || '',
            role: 'patient'
          };
          await setDoc(doc(db, 'users', currentUser.uid), newProfile);
          setProfile({ id: currentUser.uid, ...newProfile } as UserProfile);
        }
      } else {
        setProfile(null);
      }
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const q = query(collection(db, 'doctors'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docsList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Doctor));
      setDoctors(docsList);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (user) {
      const q = query(
        collection(db, 'bookings'),
        where(profile?.role === 'doctor' ? 'doctorId' : 'patientId', '==', user.uid)
      );
      const unsubscribe = onSnapshot(q, (snapshot) => {
        const bookingsList = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Booking));
        setBookings(bookingsList.sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
      });
      return () => unsubscribe();
    }
  }, [user, profile]);

  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  const handleLogout = () => signOut(auth);

  const seedDoctors = async () => {
    const exampleDoctors = [
      { name: 'د. أحمد السعدي', specialty: 'قلبية', city: 'بغداد', clinicAddress: 'المنصور، شارع الأميرات', workingHours: '4:00 PM - 9:00 PM', consultationFee: 25000, availableDays: ['الأحد', 'الثلاثاء', 'الخميس'], phone: '07801234567' },
      { name: 'د. سارة الجبوري', specialty: 'نسائية', city: 'البصرة', clinicAddress: 'الجزائر، قرب مستشفى الموسوي', workingHours: '9:00 AM - 2:00 PM', consultationFee: 20000, availableDays: ['السبت', 'الاثنين', 'الأربعاء'], phone: '07701234567' },
      { name: 'د. علي الموسوي', specialty: 'أطفال', city: 'النجف', clinicAddress: 'شارع المثنى، مجمع الحكيم', workingHours: '3:00 PM - 8:00 PM', consultationFee: 15000, availableDays: ['يومياً'], phone: '07501234567' },
      { name: 'د. مريم العبيدي', specialty: 'جلدية', city: 'أربيل', clinicAddress: 'شارع 60، قرب بارك سامي عبد الرحمن', workingHours: '10:00 AM - 4:00 PM', consultationFee: 30000, availableDays: ['الأحد', 'الاثنين', 'الأربعاء'], phone: '07509876543' },
    ];

    for (const docData of exampleDoctors) {
      await addDoc(collection(db, 'doctors'), docData);
    }
    alert('تمت إضافة بيانات تجريبية بنجاح');
  };

  const handleBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !selectedDoctor) return;

    try {
      await addDoc(collection(db, 'bookings'), {
        doctorId: selectedDoctor.id,
        doctorName: selectedDoctor.name,
        patientId: user.uid,
        patientName: user.displayName,
        patientPhone,
        date: bookingDate,
        timeSlot: bookingTime,
        status: 'pending',
        createdAt: new Date().toISOString()
      });
      setIsBookingModalOpen(false);
      alert('تم إرسال طلب الحجز بنجاح');
    } catch (error) {
      console.error('Booking failed:', error);
      alert('فشل الحجز، يرجى المحاولة لاحقاً');
    }
  };

  const filteredDoctors = doctors.filter(doc => {
    const matchesSearch = doc.name.includes(searchTerm) || doc.specialty.includes(searchTerm);
    const matchesSpecialty = selectedSpecialty === 'الكل' || doc.specialty === selectedSpecialty;
    return matchesSearch && matchesSpecialty;
  });

  if (!isAuthReady) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 font-sans" dir="rtl">
      {/* Navbar */}
      <nav className="bg-white border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white">
              <Stethoscope size={24} />
            </div>
            <h1 className="text-2xl font-black text-blue-600 tracking-tight">طبيبي العراق</h1>
          </div>

          <div className="flex items-center gap-4">
            {user && user.email === 'sand010man@gmail.com' && (
              <button 
                onClick={seedDoctors}
                className="text-xs bg-gray-100 px-3 py-1 rounded-lg font-bold text-gray-500 hover:bg-gray-200"
              >
                إضافة بيانات تجريبية
              </button>
            )}
            {user ? (
              <div className="flex items-center gap-3">
                <div className="text-left hidden sm:block">
                  <p className="text-sm font-bold text-gray-900">{user.displayName}</p>
                  <p className="text-xs text-gray-500 capitalize">{profile?.role}</p>
                </div>
                <button 
                  onClick={handleLogout}
                  className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                >
                  <LogOut size={20} />
                </button>
              </div>
            ) : (
              <button
                onClick={handleLogin}
                className="bg-blue-600 text-white px-6 py-2 rounded-xl font-bold hover:bg-blue-700 transition-colors flex items-center gap-2"
              >
                <UserIcon size={18} />
                تسجيل الدخول
              </button>
            )}
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Hero & Search */}
        <div className="mb-12 text-center">
          <h2 className="text-4xl font-black text-gray-900 mb-4">ابحث عن طبيبك واحجز موعدك بسهولة</h2>
          <p className="text-gray-500 text-lg mb-8">أفضل الأطباء في العراق في مكان واحد</p>
          
          <div className="max-w-2xl mx-auto flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="ابحث باسم الطبيب أو الاختصاص..."
                className="w-full pr-12 pl-4 py-4 bg-white border border-gray-100 rounded-2xl shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <select
              className="px-6 py-4 bg-white border border-gray-100 rounded-2xl shadow-sm focus:ring-2 focus:ring-blue-500 outline-none transition-all font-bold text-gray-700"
              value={selectedSpecialty}
              onChange={(e) => setSelectedSpecialty(e.target.value)}
            >
              {specialties.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Doctors List */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-gray-900">الأطباء المتاحون ({filteredDoctors.length})</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredDoctors.map(doctor => (
                <DoctorCard 
                  key={doctor.id} 
                  doctor={doctor} 
                  onBook={(doc) => {
                    if (!user) {
                      handleLogin();
                    } else {
                      setSelectedDoctor(doc);
                      setIsBookingModalOpen(true);
                    }
                  }}
                />
              ))}
              {filteredDoctors.length === 0 && (
                <div className="col-span-full py-20 text-center bg-white rounded-3xl border border-dashed border-gray-200">
                  <p className="text-gray-400">لا يوجد أطباء يطابقون بحثك حالياً</p>
                </div>
              )}
            </div>
          </div>

          {/* User Bookings Sidebar */}
          <div className="space-y-6">
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
              <div className="flex items-center gap-2 mb-6">
                <ClipboardList className="text-blue-600" size={24} />
                <h3 className="text-xl font-bold text-gray-900">حجوزاتي</h3>
              </div>
              
              {!user ? (
                <div className="text-center py-8">
                  <p className="text-gray-400 text-sm mb-4">سجل دخولك لمشاهدة حجوزاتك</p>
                  <button onClick={handleLogin} className="text-blue-600 font-bold text-sm underline">تسجيل الدخول</button>
                </div>
              ) : (
                <div className="space-y-4">
                  {bookings.map(booking => (
                    <div key={booking.id} className="p-4 rounded-2xl bg-gray-50 border border-gray-100">
                      <div className="flex justify-between items-start mb-2">
                        <p className="font-bold text-gray-900">{booking.doctorName}</p>
                        <span className={`text-[10px] px-2 py-1 rounded-full font-bold uppercase ${
                          booking.status === 'confirmed' ? 'bg-green-100 text-green-600' :
                          booking.status === 'cancelled' ? 'bg-red-100 text-red-600' :
                          'bg-yellow-100 text-yellow-600'
                        }`}>
                          {booking.status === 'confirmed' ? 'مؤكد' : booking.status === 'cancelled' ? 'ملغي' : 'قيد الانتظار'}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-gray-500">
                        <Calendar size={14} />
                        <span>{booking.date}</span>
                        <ClockIcon size={14} className="mr-2" />
                        <span>{booking.timeSlot}</span>
                      </div>
                    </div>
                  ))}
                  {bookings.length === 0 && (
                    <p className="text-center text-gray-400 text-sm py-8">ليس لديك حجوزات حالياً</p>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Booking Modal */}
      <AnimatePresence>
        {isBookingModalOpen && selectedDoctor && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsBookingModalOpen(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden"
            >
              <div className="p-6 border-b border-gray-100 flex items-center justify-between">
                <h3 className="text-xl font-bold text-gray-900">حجز موعد جديد</h3>
                <button onClick={() => setIsBookingModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                  <X size={24} />
                </button>
              </div>
              
              <form onSubmit={handleBooking} className="p-6 space-y-4">
                <div className="bg-blue-50 p-4 rounded-2xl mb-4">
                  <p className="text-sm text-blue-600 font-bold mb-1">الطبيب المختار</p>
                  <p className="text-lg font-black text-blue-900">{selectedDoctor.name}</p>
                  <p className="text-sm text-blue-700">{selectedDoctor.specialty}</p>
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">رقم الهاتف</label>
                  <input
                    type="tel"
                    required
                    placeholder="07XXXXXXXXX"
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                    value={patientPhone}
                    onChange={(e) => setPatientPhone(e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">التاريخ</label>
                    <input
                      type="date"
                      required
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                      value={bookingDate}
                      onChange={(e) => setBookingDate(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-2">الوقت</label>
                    <input
                      type="time"
                      required
                      className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:ring-2 focus:ring-blue-500"
                      value={bookingTime}
                      onChange={(e) => setBookingTime(e.target.value)}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-2xl transition-all shadow-lg shadow-blue-200 mt-4"
                >
                  تأكيد الحجز
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
