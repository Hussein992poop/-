import React from 'react';
import { Doctor } from '../types';
import { MapPin, Stethoscope, Clock, Wallet, Calendar as CalendarIcon } from 'lucide-react';
import { motion } from 'motion/react';

interface DoctorCardProps {
  doctor: Doctor;
  onBook: (doctor: Doctor) => void;
}

export const DoctorCard: React.FC<DoctorCardProps> = ({ doctor, onBook }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 bg-blue-50 rounded-full flex items-center justify-center text-blue-600">
            <Stethoscope size={28} />
          </div>
          <div>
            <h3 className="text-xl font-bold text-gray-900">{doctor.name}</h3>
            <p className="text-blue-600 font-medium">{doctor.specialty}</p>
          </div>
        </div>
        <div className="flex items-center gap-1 text-gray-500 text-sm">
          <MapPin size={16} />
          <span>{doctor.city}</span>
        </div>
      </div>

      <div className="space-y-3 mb-6">
        <div className="flex items-center gap-3 text-gray-600">
          <Clock size={18} className="text-gray-400" />
          <span className="text-sm">{doctor.workingHours}</span>
        </div>
        <div className="flex items-center gap-3 text-gray-600">
          <CalendarIcon size={18} className="text-gray-400" />
          <span className="text-sm">{doctor.availableDays.join(', ')}</span>
        </div>
        <div className="flex items-center gap-3 text-gray-600">
          <Wallet size={18} className="text-gray-400" />
          <span className="text-sm font-semibold">{doctor.consultationFee.toLocaleString()} د.ع</span>
        </div>
      </div>

      <div className="flex items-center gap-2 text-gray-500 text-xs mb-6">
        <MapPin size={14} />
        <span>{doctor.clinicAddress}</span>
      </div>

      <button
        onClick={() => onBook(doctor)}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2"
      >
        <CalendarIcon size={18} />
        احجز الآن
      </button>
    </motion.div>
  );
};
