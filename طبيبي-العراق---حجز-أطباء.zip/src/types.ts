export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  city: string;
  clinicAddress: string;
  workingHours: string;
  consultationFee: number;
  availableDays: string[];
  phone: string;
  uid?: string;
}

export interface Booking {
  id: string;
  doctorId: string;
  doctorName: string;
  patientId: string;
  patientName: string;
  patientPhone: string;
  date: string;
  timeSlot: string;
  status: 'pending' | 'confirmed' | 'cancelled';
  createdAt: string;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: 'patient' | 'doctor' | 'admin';
  phone?: string;
}
